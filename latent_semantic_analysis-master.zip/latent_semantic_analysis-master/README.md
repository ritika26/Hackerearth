# Topic Modeling using Latent Semantic Analysis (LSA)

LSA is a technique which is used to extract abstract topics from a set text documents. Click [here](https://www.analyticsvidhya.com/blog/2018/10/stepwise-guide-topic-modeling-latent-semantic-analysis/) to read the full blog post.
